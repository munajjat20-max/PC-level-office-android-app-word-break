# Word Break v1.4.0 for Android — Release & GitHub Guide

This package contains **Word Break v1.4.0** (`word-break-1.4.0.apk` and the full open-source Rust + Android repository).

## What's New in Word Break v1.4.0
1. **Renamed to Word Break (`v1.4.0`, `versionCode = 1400`)**: Updated across `AndroidManifest.xml`, `resources.arsc`, `Cargo.toml`, and UI chrome.
2. **Clipboard at the End of the Home Ribbon**: `Paste`, `Cut`, `Copy`, and `Format Painter` (`Clipboard`) are positioned at the rightmost end of the `Home` ribbon (`crates/ui-egui/src/ribbon.rs` and `assets/index.html`).
3. **Native Android File Explorer (`1001`), Insert Picture (`1002`) & Choose Directory / Save (`1003`)**:
   - Compiled `MainActivity.onActivityResult(int requestCode, int resultCode, Intent data)` directly into `classes.dex` to stream files and images via `ContentResolver` and Base64 directly into the document engine.
   - Includes a built-in **Directory & File Manager** (`File › Browse Dir / Save to Dir`) for creating folders, choosing save directories, and launching the native Android OS directory/file chooser (`Intent.ACTION_CREATE_DOCUMENT`).
4. **Manual Font Size Typing & 50 Built-In Fonts (+ Custom `.ttf`/`.otf` Loader)**:
   - Type any custom font size (`1` to `500` pt, including decimals like `10.5` or `13.5`) directly into the Font Size box and press Enter, or pick from the preset dropdown (`8` to `72` pt).
   - Includes 50 font families plus a `+Font` button to load custom `.ttf`, `.otf`, or `.woff2` font files.
5. **Working Zoom In & Zoom Out (`10%` to `500%`)**:
   - Status bar `-` / `+` buttons, Zoom Slider, `↔ Fit` button, `View › Zoom` modal, and two-finger pinch-to-zoom dynamically scale all pages and update scroll bounds.
6. **Multi-Page Layout, Automatic Page Overflow & Page Break**:
   - True multi-page `.page-sheet` rendering (`Page 1`, `Page 2`, `Page 3`, ...) with headers, footers, and visual page gaps.
   - Typing or holding Spacebar to the end of a page automatically splits overflowing text onto a new page (`Page 2`), and `Insert › Page Break` (`Ctrl+Enter`), `Blank Page`, and `Cover Page` add pages on demand.
7. **Vertically Stacked Equations, Custom Equation Builder & 8-Category Symbol Dialog**:
   - `Insert › Equation` opens the full gallery (all 14 built-in equations from `crates/engine/src/math_gallery.rs`) plus a **Custom Stacked Equation Builder** where fractions, summations, integrals, limits, and multi-line equations stack vertically (`flex-direction: column`).
   - `Insert › Symbol` opens the full Symbol Picker with all 8 symbol subsets, Unicode codepoint readout, and Recently Used Symbols.
8. **Fixed Dark Mode Visibility**:
   - `View › Dark UI Mode` switches the ribbon and chrome to a high-contrast dark theme while keeping the document page crisp white with dark ink; `View › Switch Page Mode` optionally toggles dark paper.
9. **Pure-JS DEFLATE `.docx`, `.doc`, `.odt`, `.rtf`, `.html`, `.md`, `.txt` Support**:
   - Built-in RFC 1951 raw DEFLATE decompressor and ZIP reader/writer opens and exports real `.docx` and `.doc` files offline.
