//! WordCraft Android standalone runner.
#![deny(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::unimplemented, clippy::todo, clippy::unreachable)]

fn main() -> std::process::ExitCode {
    let sample = std::env::args().any(|a| a == "--sample");
    let storage = std::env::var_os("WORDCRAFT_ANDROID_STORAGE").map(std::path::PathBuf::from);
    match wordcraft_android::run_app(storage, sample) {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("wordcraft-android error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
