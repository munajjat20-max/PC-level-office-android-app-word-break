//! WordCraft for Android (`wordcraft-android`).
//!
//! Runs [`wordcraft_ui_egui::WordApp`] on Android phones and tablets with:
//! - Responsive screen sizing for portrait/landscape phones (`< 600dp`) and tablets (`>= 600dp`)
//! - Full software IME and hardware (Bluetooth / USB OTG) keyboard integration
//! - One-tap Keyboard Lock / Unlock (`ui.keyboardLock`) to suppress the on-screen soft keyboard
//!   when using a Bluetooth or OTG physical keyboard, or lock all keyboard input
//! - Android Storage Access Framework (`Intent.ACTION_OPEN_DOCUMENT` / `ACTION_CREATE_DOCUMENT`)
//!   file explorer integration through [`AndroidBridge`]
//! - Android native Share sheet (`Intent.ACTION_SEND` + `FileProvider`) integration via
//!   [`Services::share`]
#![deny(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::unimplemented, clippy::todo, clippy::unreachable)]

use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use serde::{Deserialize, Serialize};
use wordcraft_engine::Session;
use wordcraft_ui_egui::{FileDialogAnswer, FileDialogRequest, Inbox, Services, UiState, WordApp};

/// Outbound host requests written by the Rust UI thread for the Android `MainActivity` bridge
/// (Storage Access Framework file explorer, native Share chooser, and `InputMethodManager`
/// soft-keyboard lock state). Using a lock-protected queue and bridge directory avoids any
/// `unsafe` JNI calls inside the Rust crate (`unsafe_code = "forbid"`).
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "camelCase")]
pub enum HostAction {
    /// Open the Android system file explorer (`Intent.ACTION_OPEN_DOCUMENT`) for `purpose`
    /// (`document`, `picture`, `font`, `recipients`). Selected files arrive in `inbox`.
    OpenExplorer { purpose: String, multiple: bool },
    /// Save `bytes` to a user-chosen path in the Android file explorer
    /// (`Intent.ACTION_CREATE_DOCUMENT`) with suggested `name`.
    SaveExplorer { name: String, path: PathBuf },
    /// Launch Android's native `Intent.ACTION_SEND` share chooser for `path` with `mime`.
    ShareFile { name: String, mime: String, path: PathBuf },
    /// Show (`true`) or hide/lock (`false`) the Android on-screen soft keyboard
    /// (`InputMethodManager`).
    SoftKeyboard { visible: bool },
}

/// Shared state between the Android Activity host and [`AndroidShell`].
#[derive(Clone, Default)]
pub struct AndroidBridge {
    /// Outbound actions queued for the Android Activity bridge.
    pub actions: Arc<Mutex<Vec<HostAction>>>,
    /// Incoming files picked in the Android file explorer or opened from external intents.
    pub inbox: Inbox,
    /// App-private storage directory on Android (`/data/data/ai.storyteller.wordcraft/files`).
    pub storage_dir: Option<PathBuf>,
    /// Last soft-keyboard visibility state requested by the UI (`true` = unlocked/shown,
    /// `false` = locked/hidden for Bluetooth & OTG keyboards).
    pub soft_keyboard_visible: Arc<Mutex<bool>>,
}

impl AndroidBridge {
    pub fn new(storage_dir: Option<PathBuf>) -> Self {
        Self {
            actions: Arc::new(Mutex::new(Vec::new())),
            inbox: Inbox::default(),
            storage_dir,
            soft_keyboard_visible: Arc::new(Mutex::new(true)),
        }
    }

    /// Record an outbound [`HostAction`] and, when `storage_dir` is configured, write a bridge
    /// command line to `<storage_dir>/bridge-outbox.jsonl` so the Android Activity host can
    /// execute the native Intent (`ACTION_OPEN_DOCUMENT`, `ACTION_CREATE_DOCUMENT`, `ACTION_SEND`)
    /// or `InputMethodManager` toggle immediately.
    pub fn push_action(&self, action: HostAction) {
        if let Some(dir) = &self.storage_dir {
            let _ = std::fs::create_dir_all(dir);
            if let Ok(line) = serde_json::to_string(&action) {
                let outbox = dir.join("bridge-outbox.jsonl");
                let prev = std::fs::read_to_string(&outbox).unwrap_or_default();
                let _ = std::fs::write(&outbox, format!("{prev}{line}
"));
            }
        }
        self.actions.lock().unwrap_or_else(|e| e.into_inner()).push(action);
    }

    /// Drain all queued [`HostAction`]s.
    pub fn drain_actions(&self) -> Vec<HostAction> {
        std::mem::take(&mut *self.actions.lock().unwrap_or_else(|e| e.into_inner()))
    }

    /// Deliver a file picked from the Android File Explorer (`DocumentsUI`) into the app's inbox.
    pub fn deliver_file(&self, name: impl Into<String>, bytes: Vec<u8>) {
        self.inbox.lock().unwrap_or_else(|e| e.into_inner()).push((name.into(), bytes));
    }

    /// Poll `<storage_dir>/bridge-inbox/` for files dropped by Android's `onActivityResult`
    /// (`Intent.ACTION_OPEN_DOCUMENT` or `Intent.ACTION_VIEW`).
    pub fn poll_filesystem_inbox(&self) -> usize {
        let Some(dir) = self.storage_dir.as_ref().map(|d| d.join("bridge-inbox")) else {
            return 0;
        };
        let Ok(entries) = std::fs::read_dir(&dir) else {
            return 0;
        };
        let mut count = 0usize;
        for entry in entries.flatten() {
            let path = entry.path();
            if !path.is_file() {
                continue;
            }
            let Some(name) = path.file_name().map(|n| n.to_string_lossy().to_string()) else {
                continue;
            };
            if let Ok(bytes) = std::fs::read(&path) {
                self.deliver_file(name, bytes);
                let _ = std::fs::remove_file(&path);
                count += 1;
            }
        }
        count
    }

    /// Construct [`Services`] wired to this [`AndroidBridge`].
    pub fn services(&self) -> Services {
        let open_bridge = self.clone();
        let dialog_bridge = self.clone();
        let save_bridge = self.clone();
        let share_bridge = self.clone();
        let kb_bridge = self.clone();
        Services {
            open_async: Some(Box::new(move |purpose: &str| {
                open_bridge.push_action(HostAction::OpenExplorer {
                    purpose: purpose.to_string(),
                    multiple: purpose == "font",
                });
            })),
            file_dialog: Some(Box::new(move |req: FileDialogRequest| {
                let (tx, rx) = std::sync::mpsc::channel::<FileDialogAnswer>();
                match req {
                    FileDialogRequest::Open { purpose } => {
                        dialog_bridge.push_action(HostAction::OpenExplorer { purpose, multiple: false });
                        let _ = tx.send(Ok(Vec::new()));
                    }
                    FileDialogRequest::OpenMany { purpose } => {
                        dialog_bridge.push_action(HostAction::OpenExplorer { purpose, multiple: true });
                        let _ = tx.send(Ok(Vec::new()));
                    }
                    FileDialogRequest::Save { name } => {
                        let out_dir = dialog_bridge
                            .storage_dir
                            .clone()
                            .unwrap_or_else(std::env::temp_dir)
                            .join("exports");
                        let _ = std::fs::create_dir_all(&out_dir);
                        let safe_name = sanitize_file_name(&name);
                        let target = out_dir.join(&safe_name);
                        dialog_bridge.push_action(HostAction::SaveExplorer {
                            name: safe_name,
                            path: target.clone(),
                        });
                        let _ = tx.send(Ok(vec![target.to_string_lossy().to_string()]));
                    }
                }
                rx
            })),
            download: Some(Box::new(move |name: &str, bytes: &[u8]| {
                let out_dir = save_bridge
                    .storage_dir
                    .clone()
                    .unwrap_or_else(std::env::temp_dir)
                    .join("exports");
                std::fs::create_dir_all(&out_dir).map_err(|e| e.to_string())?;
                let safe_name = sanitize_file_name(name);
                let target = out_dir.join(&safe_name);
                std::fs::write(&target, bytes).map_err(|e| e.to_string())?;
                save_bridge.push_action(HostAction::SaveExplorer {
                    name: safe_name,
                    path: target,
                });
                Ok(())
            })),
            share: Some(Box::new(move |name: &str, mime: &str, bytes: &[u8]| {
                let share_dir = share_bridge
                    .storage_dir
                    .clone()
                    .unwrap_or_else(std::env::temp_dir)
                    .join("share");
                std::fs::create_dir_all(&share_dir).map_err(|e| e.to_string())?;
                let safe_name = sanitize_file_name(name);
                let target = share_dir.join(&safe_name);
                std::fs::write(&target, bytes).map_err(|e| e.to_string())?;
                share_bridge.push_action(HostAction::ShareFile {
                    name: safe_name,
                    mime: mime.to_string(),
                    path: target,
                });
                Ok(())
            })),
            set_soft_keyboard: Some(Box::new(move |visible: bool| {
                *kb_bridge.soft_keyboard_visible.lock().unwrap_or_else(|e| e.into_inner()) = visible;
                kb_bridge.push_action(HostAction::SoftKeyboard { visible });
            })),
            inbox: Some(self.inbox.clone()),
            ..Default::default()
        }
    }
}

/// Strip directory traversal characters from a suggested file name.
pub fn sanitize_file_name(name: &str) -> String {
    let base = Path::new(name)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "Document.docx".to_string());
    let cleaned: String = base
        .chars()
        .map(|c| if matches!(c, '/' | '\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') { '_' } else { c })
        .collect();
    if cleaned.trim().is_empty() {
        "Document.docx".to_string()
    } else {
        cleaned
    }
}

/// The eframe application wrapper for Android phones and tablets.
pub struct AndroidShell {
    pub app: WordApp,
    pub bridge: AndroidBridge,
    last_prefs_json: String,
}

impl AndroidShell {
    pub fn new(bridge: AndroidBridge, sample: bool) -> Self {
        let region = wordcraft_ui_egui::i18n::system_region();
        let doc = if sample {
            wordcraft_engine::sample::sample_document()
        } else {
            wordcraft_engine::blank_document(&region)
        };
        let mut session = Session::new(doc);
        session.system_region = region;
        let mut app = WordApp::new(session, bridge.services());
        app.ui.responsive_screen_fit = true;
        if let Some(dir) = &bridge.storage_dir {
            let prefs_file = dir.join("ui.json");
            if let Ok(bytes) = std::fs::read(&prefs_file)
                && let Some(ui) = UiState::from_json(&bytes)
            {
                app.apply_prefs(ui);
                app.ui.responsive_screen_fit = true;
            }
            let dict_file = dir.join(Session::USER_DICT_FILE);
            wordcraft_proof::load_user_dictionary(&dict_file);
            app.session.user_dict_path = Some(dict_file);
            let fonts_dir = dir.join("fonts");
            let _ = wordcraft_fonts::FontDb::global().load_user_fonts(&fonts_dir);
        }
        Self {
            app,
            bridge,
            last_prefs_json: String::new(),
        }
    }

    /// Persist `ui.json` whenever preferences (such as `keyboard_locked`, theme, or recent files)
    /// change, because Android may kill backgrounded activities without calling `on_exit`.
    pub fn sync_prefs(&mut self) {
        let Some(dir) = &self.bridge.storage_dir else { return };
        let Ok(json) = serde_json::to_string(&self.app.prefs()) else { return };
        if json != self.last_prefs_json {
            let _ = std::fs::create_dir_all(dir);
            if std::fs::write(dir.join("ui.json"), json.as_bytes()).is_ok() {
                self.last_prefs_json = json;
            }
        }
    }
}

impl eframe::App for AndroidShell {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if self.bridge.poll_filesystem_inbox() > 0 {
            ctx.request_repaint();
        }
        self.app.logic(ctx);
        self.sync_prefs();
    }

    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.app.raw_input_hook(raw);
    }

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.app.ui(ui);
    }

    fn on_exit(&mut self) {
        self.sync_prefs();
    }
}

/// Start WordCraft on Android or desktop preview.
pub fn run_app(storage_dir: Option<PathBuf>, sample: bool) -> Result<(), String> {
    let bridge = AndroidBridge::new(storage_dir);
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("WordCraft")
            .with_inner_size([1080.0, 720.0])
            .with_min_inner_size([320.0, 480.0]),
        ..Default::default()
    };
    eframe::run_native(
        "WordCraft",
        options,
        Box::new(move |_cc| Ok(Box::new(AndroidShell::new(bridge, sample)))),
    )
    .map_err(|e| format!("eframe failed: {e}"))
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn android_shell_wires_keyboard_lock_share_and_saf_explorer() {
        let tmp = std::env::temp_dir().join(format!("wordcraft-android-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&tmp);
        let bridge = AndroidBridge::new(Some(tmp.clone()));
        let mut shell = AndroidShell::new(bridge.clone(), false);

        // 1. Keyboard lock / unlock (for Bluetooth and OTG keyboards)
        assert!(*bridge.soft_keyboard_visible.lock().unwrap());
        let r = shell.app.run("ui.keyboardLock", json!({"value": true})).unwrap();
        assert_eq!(r["locked"], json!(true));
        assert!(!*bridge.soft_keyboard_visible.lock().unwrap());

        // 2. Native Android Share sheet (`Intent.ACTION_SEND`)
        shell.app.run("text.insert", json!({"text": "Android document content"})).unwrap();
        let shared = shell.app.run("file.share", json!({"format": "docx"})).unwrap();
        assert_eq!(shared["mime"], json!("application/vnd.openxmlformats-officedocument.wordprocessingml.document"));

        // 3. Android Storage Access Framework (`Intent.ACTION_OPEN_DOCUMENT`)
        shell.app.run("ui.openFileDialog", json!({})).unwrap();

        let actions = bridge.drain_actions();
        assert!(actions.iter().any(|a| matches!(a, HostAction::SoftKeyboard { visible: false })));
        assert!(actions.iter().any(|a| matches!(a, HostAction::ShareFile { mime, .. } if mime.contains("wordprocessingml"))));
        assert!(actions.iter().any(|a| matches!(a, HostAction::OpenExplorer { purpose, .. } if purpose == "document")));

        let _ = std::fs::remove_dir_all(&tmp);
    }
}
