<h1 align="center">Word Break v1.4.0</h1>

<p align="center">
  <b>An open-source, modern word processor for Android (Phone &amp; Tablet), Desktop, Web, and CLI — powered by Rust.</b>
</p>

<p align="center">
  <img alt="Version 1.4.0" src="https://img.shields.io/badge/version-1.4.0-185abd?style=flat-square">
  <img alt="Written in Rust" src="https://img.shields.io/badge/written%20in-Rust-2b47b5?style=flat-square&logo=rust&logoColor=white">
  <img alt="Runs on Android, macOS, Windows, Linux, BSD and Web" src="https://img.shields.io/badge/runs%20on-Android%20%C2%B7%20Desktop%20%C2%B7%20Web-3b5bdb?style=flat-square&logo=android&logoColor=white">
  <img alt="License: Apache-2.0 OR MIT" src="https://img.shields.io/badge/license-Apache--2.0%20%2F%20MIT-2b47b5?style=flat-square">
</p>

---

## Overview

**Word Break v1.4.0** is an open-source word processor for **Android phones and tablets** (as well as desktop and web), based on the open-source [WordCraft (`storytold/wordcraft`)](https://github.com/storytold/wordcraft) project by the ArtCraft team under the **Apache-2.0 / MIT** dual license.

### Key Features in Word Break v1.4.0 (Android Edition)
- **Full Ribbon Interface (Clipboard at Ribbon End)**: Complete `File`, `Home`, `Insert`, `Draw`, `Design`, `Layout`, `References`, `Mailings`, `Review`, `View`, and `Help` ribbon tabs, plus contextual `Table Layout`, `Picture Format`, and `Equation` tabs — with `Paste`, `Cut`, `Copy`, and `Format Painter` (`Clipboard`) placed at the far-right end of the `Home` tab.
- **Native Android File Explorer, Picture Picker & Directory Manager**:
  - Open files directly from Android's native `DocumentsUI` file manager (`Intent.ACTION_OPEN_DOCUMENT`).
  - Insert pictures from your device gallery or file manager (`Intent.ACTION_GET_CONTENT` `image/*`), resize (`50%`, `75%`, `100%`), and toggle borders.
  - Save documents to any Android OS folder (`Intent.ACTION_CREATE_DOCUMENT`) or manage custom folders in the built-in **Directory & File Manager**.
- **Manual Font Size Typing & 50 Fonts**:
  - Type any point size manually (`1`–`500` pt, including decimals like `10.5` or `13.5`) or pick from standard presets (`8`–`72` pt).
  - Choose from **50 built-in font families** or load your own `.ttf`, `.otf`, or `.woff2` font files via `+Font`.
- **True Multi-Page Layout & Page Breaks**:
  - Automatic multi-page overflow (`Page 1`, `Page 2`, `Page 3`, ...) when typing or pressing Spacebar to the end of a page, plus explicit **Page Break** (`Ctrl+Enter`), **Blank Page**, and **Cover Page**.
- **Working Zoom In & Zoom Out (`10%`–`500%`)**:
  - Status bar `−` / `+` buttons, zoom slider, `↔ Fit` page-width button, Zoom dialog, and two-finger pinch-to-zoom.
- **Vertically Stacked Equations & 8-Category Symbol Picker**:
  - Includes all 14 built-in equations and 14 math structure templates from `crates/engine/src/math_gallery.rs`, plus a live **Custom Stacked Equation Builder** where multi-line equations, fractions, summations, integrals, and limits stack vertically.
  - Full **Symbol Dialog** covering Basic Math, Greek Letters, Letter-Like Symbols, Operators, Arrows, Negated Relations, Geometry, and Currency/Legal symbols.
- **3-State Keyboard Lock for Bluetooth & OTG Keyboards**:
  - Cycle between `⌨️ KB: Unlocked`, `⌨️ KB: BT/OTG Only` (suppresses the soft keyboard while keeping hardware keyboard shortcuts active), and `🔒 KB: Full Lock` (read-only mode).
- **Fixed Dark Mode Visibility**:
  - High-contrast Dark UI mode keeps the document page crisp white with dark ink by default, with a separate **Switch Page Mode** toggle for dark paper.
- **Offline `.docx`, `.doc`, `.odt`, `.rtf`, `.html`, `.md`, `.txt` Support**:
  - Pure-JS RFC 1951 DEFLATE + ZIP reader/writer opens and exports compressed `.docx` and `.doc` files completely offline.

---

## Installing the Android APK

1. Download **`word-break-1.4.0.apk`** from the [`releases/`](releases/) folder or the GitHub Releases page.
2. Transfer it to your Android phone or tablet and tap it to install (signed with both APK Signature Scheme v1 and v2).

---

## Building from Source

### Android APK & Rust JNI Library (`apps/wordcraft-android`)
```bash
# Run Android crate and UI unit tests
cargo test -p wordcraft-android
cargo test -p wordcraft-ui-egui keyboard_lock

# Build native Android shared libraries via cargo-ndk
cargo ndk -t arm64-v8a -t x86_64 -o packaging/android/app/src/main/jniLibs build --release -p wordcraft-android

# Assemble APK via Gradle
cd packaging/android && gradle assembleRelease
```

### Desktop & CLI
```bash
cargo run --release -p wordcraft -- --sample
cargo run --release -p wordcraft-cli -- convert report.docx report.pdf
```

---

## License & Attribution

**Word Break v1.4.0** is dual-licensed under the **Apache License, Version 2.0** ([`LICENSE-APACHE`](LICENSE-APACHE)) or the **MIT License** ([`LICENSE-MIT`](LICENSE-MIT)), at your option.

This project is based on [WordCraft (`storytold/wordcraft`)](https://github.com/storytold/wordcraft) by the ArtCraft team (`Copyright (c) 2026 ArtCraft Team and the WordCraft contributors`). Required notices and third-party asset attributions are documented in [`NOTICE`](NOTICE) and [`ATTRIBUTION.md`](ATTRIBUTION.md). Word Break is an independent derivative work and is not endorsed by or affiliated with the ArtCraft Team.
