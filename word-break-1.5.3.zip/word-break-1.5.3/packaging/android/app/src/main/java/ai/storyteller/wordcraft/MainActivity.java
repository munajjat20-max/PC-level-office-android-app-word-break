package ai.storyteller.wordcraft;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * WordCraft Android Activity host:
 * - Responsive phone & tablet viewport configuration
 * - Hardware (Bluetooth / USB OTG) & software keyboard integration with Keyboard Lock/Unlock
 * - Android Storage Access Framework (`Intent.ACTION_OPEN_DOCUMENT` / `ACTION_CREATE_DOCUMENT`)
 * - Android native Share sheet (`Intent.ACTION_SEND` + `WordCraftShareProvider`)
 */
public class MainActivity extends Activity {
    private static final int REQ_OPEN_DOCUMENT = 1001;
    private static final int REQ_CREATE_DOCUMENT = 1002;
    private static final int REQ_WEB_FILE_CHOOSER = 1003;

    private WebView webView;
    private boolean keyboardLocked = false;
    private byte[] pendingSaveBytes = null;
    private ValueCallback<Uri[]> filePathCallback = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidHostBridge(), "WordCraftAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleCustomScheme(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleCustomScheme(request.getUrl().toString());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                handleIncomingIntent(getIntent());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> callback,
                FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(Intent.createChooser(intent, "Open with WordCraft"), REQ_WEB_FILE_CHOOSER);
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private boolean handleCustomScheme(String url) {
        if (url == null) return false;
        if (url.startsWith("wordcraft://kbd-lock")) {
            setKeyboardLockedInternal(true);
            return true;
        }
        if (url.startsWith("wordcraft://kbd-unlock")) {
            setKeyboardLockedInternal(false);
            return true;
        }
        if (url.startsWith("wordcraft://explorer")) {
            openAndroidFileExplorer("*/*");
            return true;
        }
        if (url.startsWith("wordcraft://share")) {
            String payload = Uri.decode(url.substring("wordcraft://share".length()));
            if (payload.startsWith("?text=")) {
                payload = payload.substring(6);
            }
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, payload);
            startActivity(Intent.createChooser(send, "Share WordCraft Document"));
            return true;
        }
        return false;
    }

    private void setKeyboardLockedInternal(final boolean locked) {
        keyboardLocked = locked;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    webView.setShowSoftInputOnFocus(!locked);
                }
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (locked) {
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(webView.getWindowToken(), 0);
                    }
                } else {
                    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
                    webView.requestFocus();
                    if (imm != null) {
                        imm.showSoftInput(webView, InputMethodManager.SHOW_IMPLICIT);
                    }
                }
            }
        });
    }

    private void openAndroidFileExplorer(String mimeType) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType != null && !mimeType.isEmpty() ? mimeType : "*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
            "application/vnd.oasis.opendocument.text",
            "application/rtf",
            "text/rtf",
            "text/plain",
            "text/markdown",
            "text/html",
            "*/*"
        });
        startActivityForResult(intent, REQ_OPEN_DOCUMENT);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri uri = intent.getData();
        if (uri == null && Intent.ACTION_SEND.equals(action)) {
            uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri != null) {
            deliverUriToApp(uri);
        }
    }

    private void deliverUriToApp(Uri uri) {
        try {
            String name = queryDisplayName(uri);
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return;
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[16384];
            int n;
            while ((n = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
            }
            in.close();
            final String b64 = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
            final String safeName = name.replace("\", "\\").replace("'", "\'");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript(
                        "window.wordcraftReceiveAndroidFile && window.wordcraftReceiveAndroidFile('" + safeName + "', '" + b64 + "');",
                        null
                    );
                }
            });
        } catch (Exception ignored) {
        }
    }

    private String queryDisplayName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        result = cursor.getString(idx);
                    }
                }
            } finally {
                if (cursor != null) cursor.close();
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result != null ? result : "Document.docx";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_WEB_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_OPEN_DOCUMENT) {
            deliverUriToApp(uri);
        } else if (requestCode == REQ_CREATE_DOCUMENT && pendingSaveBytes != null) {
            try {
                OutputStream out = getContentResolver().openOutputStream(uri, "wt");
                if (out != null) {
                    out.write(pendingSaveBytes);
                    out.flush();
                    out.close();
                }
            } catch (Exception ignored) {
            } finally {
                pendingSaveBytes = null;
            }
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        // Hardware Bluetooth / USB OTG keyboards dispatch KeyEvents directly while soft keyboard stays locked
        if (keyboardLocked) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(webView.getWindowToken(), 0);
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public final class AndroidHostBridge {
        @JavascriptInterface
        public void setKeyboardLocked(boolean locked) {
            setKeyboardLockedInternal(locked);
        }

        @JavascriptInterface
        public boolean isKeyboardLocked() {
            return keyboardLocked;
        }

        @JavascriptInterface
        public void openFileExplorer(String mimeType) {
            openAndroidFileExplorer(mimeType);
        }

        @JavascriptInterface
        public void saveFileToExplorer(String suggestedName, String mimeType, String base64Data) {
            try {
                pendingSaveBytes = Base64.decode(base64Data, Base64.DEFAULT);
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mimeType != null && !mimeType.isEmpty() ? mimeType : "application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
                startActivityForResult(intent, REQ_CREATE_DOCUMENT);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void shareFile(String fileName, String mimeType, String base64Data) {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                File shareDir = new File(getFilesDir(), "share");
                if (!shareDir.exists()) {
                    shareDir.mkdirs();
                }
                String safeName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                File out = new File(shareDir, safeName);
                FileOutputStream fos = new FileOutputStream(out);
                fos.write(bytes);
                fos.flush();
                fos.close();

                Uri contentUri = WordCraftShareProvider.uriForFile(out);
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType(mimeType != null ? mimeType : "application/octet-stream");
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, safeName);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share " + safeName));
            } catch (Exception ignored) {
            }
        }
    }
}
