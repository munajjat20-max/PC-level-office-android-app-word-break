# WordCraft for Android (`packaging/android`)

This directory contains the Android application packaging for **WordCraft**, supporting both Android phones and tablets.

## Key Features
- **Phone & Tablet Responsive Layout**: Automatically adapts ribbon groups, title bar, backstage navigation, and document page-width fit (`ui.responsiveFit`) across portrait/landscape phones (`< 600dp`) and tablets (`>= 600dp`).
- **Keyboard Lock / Unlock (`ui.keyboardLock`)**: Dedicated toggle in the title bar and status bar to lock/unlock the Android on-screen soft keyboard (`InputMethodManager` + `setShowSoftInputOnFocus(false)`), built specifically for **Bluetooth** and **USB OTG** physical keyboard users, plus an optional Full Input Lock mode.
- **Android File Explorer Integration (SAF)**: Uses Android's Storage Access Framework (`Intent.ACTION_OPEN_DOCUMENT` and `Intent.ACTION_CREATE_DOCUMENT`) to browse, open, and save `.docx`, `.odt`, `.rtf`, `.md`, `.html`, and `.txt` files directly from the Android system file explorer (`DocumentsUI`).
- **Native Android Share Sheet (`Intent.ACTION_SEND`)**: Uses `WordCraftShareProvider` (`content://ai.storyteller.wordcraft.fileprovider/...` with `FLAG_GRANT_READ_URI_PERMISSION`) to share documents as `.docx`, `.pdf`, `.odt`, `.rtf`, `.html`, `.md`, or `.txt` to any Android app (Gmail, WhatsApp, Drive, Telegram, Nearby Share).

## Building Locally or on GitHub Actions
- Push to GitHub: `.github/workflows/android.yml` automatically builds the Rust crates and compiles the signed APK, uploading `wordcraft-android.apk` to workflow artifacts and GitHub Releases.
- Local build: Run `./packaging/android/package.sh`.
