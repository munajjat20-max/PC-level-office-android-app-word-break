#!/usr/bin/env bash
# Builds the WordCraft Android APK (Rust workspace + WebAssembly / Android NDK + Gradle package).
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ANDROID_DIR="${ROOT_DIR}/packaging/android"
ASSETS_DIR="${ANDROID_DIR}/app/src/main/assets"

mkdir -p "${ASSETS_DIR}"

# 1. Generate Android mipmap launcher icons from assets/app-icon/wordcraft-1024.png
python3 - "${ROOT_DIR}/assets/app-icon/wordcraft-1024.png" "${ANDROID_DIR}/app/src/main/res" <<'PY'
import sys
from pathlib import Path
from PIL import Image

src = Path(sys.argv[1])
res = Path(sys.argv[2])
img = Image.open(src).convert("RGBA")
for bucket, px in [
    ("mipmap-mdpi", 48),
    ("mipmap-hdpi", 72),
    ("mipmap-xhdpi", 96),
    ("mipmap-xxhdpi", 144),
    ("mipmap-xxxhdpi", 192),
]:
    out_dir = res / bucket
    out_dir.mkdir(parents=True, exist_ok=True)
    img.resize((px, px), Image.Resampling.LANCZOS).save(out_dir / "ic_launcher.png")
PY

# 2. If trunk and wasm32-unknown-unknown are installed, build wordcraft-web into assets/
if command -v trunk >/dev/null 2>&1; then
    echo "Building wordcraft-web WASM bundle for Android..."
    (cd "${ROOT_DIR}/apps/wordcraft-web" && trunk build --release --dist "${ASSETS_DIR}")
fi

# 3. If cargo-ndk is installed, build libwordcraft_android.so for arm64-v8a and x86_64
if command -v cargo-ndk >/dev/null 2>&1; then
    echo "Building native Rust libwordcraft_android.so via cargo-ndk..."
    cargo ndk -t arm64-v8a -t x86_64 -o "${ANDROID_DIR}/app/src/main/jniLibs" build --release -p wordcraft-android
fi

# 4. Build the signed APK with Gradle
cd "${ANDROID_DIR}"
gradle assembleRelease assembleDebug
